package com.fudn.bookingservice.service;

import com.fudn.bookingservice.client.MovieClient;
import com.fudn.bookingservice.dto.*;
import com.fudn.bookingservice.exception.ApiException;
import com.fudn.bookingservice.model.Booking;
import com.fudn.bookingservice.model.BookingDetail;
import com.fudn.bookingservice.model.BookingStatus;
import com.fudn.bookingservice.repository.BookingDetailRepository;
import com.fudn.bookingservice.repository.BookingRepository;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.DuplicateKeyException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookingService {

    private static final String ROLE_ADMIN = "ADMIN";
    private static final long CANCEL_BEFORE_HOURS = 2;

    private final BookingRepository bookingRepository;
    private final BookingDetailRepository bookingDetailRepository;
    private final MovieClient movieClient;
    private final JdbcTemplate jdbcTemplate;

    // ======================= F7: SEAT MAP =======================

    // TODO 7.6
    public SeatMapResponse getSeatMap(String showtimeId) {
        ShowtimeResponse st = fetchShowtime(showtimeId);
        List<String> booked = bookingDetailRepository
                .findSeatCodesByShowtime(showtimeId, BookingStatus.CONFIRMED)
                .stream().sorted().toList();
        int totalSeats = st.seatRows() * st.seatsPerRow();
        return new SeatMapResponse(st.showtimeId(), st.movieTitle(), st.roomName(), st.startTime(),
                st.seatRows(), st.seatsPerRow(), totalSeats, totalSeats - booked.size(), booked);
    }

    // ======================= F7: CREATE BOOKING =======================

    // TODO 7.5
    @Transactional
    public BookingResponse create(Long customerId, CreateBookingRequest request) {
        Map<String, ShowtimeResponse> showtimeCache = new HashMap<>();   // moi showtime chi goi Feign 1 lan
        Map<String, Set<String>> bookedSeatCache = new HashMap<>();
        Set<String> requestedSeats = new HashSet<>();

        Booking booking = new Booking();
        booking.setCustomerId(customerId);
        booking.setBookingDate(LocalDateTime.now());
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        BigDecimal total = BigDecimal.ZERO;

        for (BookingItemRequest item : request.items()) {
            String seat = item.seatCode();

            // BR07: khong trung ghe trong cung request
            if (!requestedSeats.add(item.showtimeId() + "#" + seat)) {
                throw ApiException.badRequest("Duplicate seat " + seat + " of showtime " + item.showtimeId() + " in request");
            }

            // BR08 + BR14: goi movie-service qua OpenFeign
            ShowtimeResponse st = showtimeCache.computeIfAbsent(item.showtimeId(), this::fetchShowtime);
            validateShowtime(st);
            validateSeat(seat, st);

            // BR09: ghe da ban cho booking CONFIRMED khac?
            Set<String> taken = bookedSeatCache.computeIfAbsent(st.showtimeId(),
                    id -> new HashSet<>(bookingDetailRepository.findSeatCodesByShowtime(id, BookingStatus.CONFIRMED)));
            if (taken.contains(seat)) {
                throw ApiException.conflict("Seat " + seat + " of showtime " + st.showtimeId() + " is already booked");
            }

            // BR10: gia lay tu server + snapshot thong tin phim
            BookingDetail detail = new BookingDetail();
            detail.setShowtimeId(st.showtimeId());
            detail.setSeatCode(seat);
            detail.setPrice(st.ticketPrice());
            detail.setMovieId(st.movieId());
            detail.setMovieTitle(st.movieTitle());
            detail.setRoomName(st.roomName());
            detail.setShowtimeStart(st.startTime());
            booking.addDetail(detail);

            total = total.add(st.ticketPrice());
        }

        booking.setTotalPrice(total);
        Booking saved = bookingRepository.save(booking);           // cascade luu luon details
        // The unique primary key also protects BR09 when concurrent requests race.
        for (BookingDetail detail : saved.getDetails()) {
            try {
                jdbcTemplate.update("INSERT INTO seat_reservation(showtime_id, seat_code, booking_id) VALUES (?, ?, ?)",
                        detail.getShowtimeId(), detail.getSeatCode(), saved.getBookingId());
            } catch (DuplicateKeyException exception) {
                throw ApiException.conflict("Seat " + detail.getSeatCode() + " of showtime "
                        + detail.getShowtimeId() + " is already booked");
            }
        }
        log.info("Booking {} created for customer {} with {} ticket(s), total {}",
                saved.getBookingId(), customerId, saved.getDetails().size(), total);
        return BookingResponse.from(saved);
    }

    // ======================= F8: HISTORY & CANCEL =======================

    // TODO 8.1
    public List<BookingResponse> getMyBookings(Long customerId) {
        return bookingRepository.findByCustomerIdOrderByBookingDateDesc(customerId)
                .stream().map(BookingResponse::from).toList();
    }

    public List<BookingResponse> getAll() {
        return bookingRepository.findAllByOrderByBookingDateDesc()
                .stream().map(BookingResponse::from).toList();
    }

    // TODO 8.2
    public BookingResponse getById(Long bookingId, Long userId, String role) {
        return BookingResponse.from(findAccessible(bookingId, userId, role));
    }

    // TODO 8.3
    @Transactional
    public BookingResponse cancel(Long bookingId, Long userId, String role) {
        Booking booking = findAccessible(bookingId, userId, role);
        if (booking.getBookingStatus() != BookingStatus.CONFIRMED) {
            throw ApiException.badRequest("Only CONFIRMED bookings can be cancelled");
        }
        if (!ROLE_ADMIN.equals(role)) {                                     // BR12
            LocalDateTime deadline = LocalDateTime.now().plusHours(CANCEL_BEFORE_HOURS);
            boolean tooLate = booking.getDetails().stream()
                    .anyMatch(d -> d.getShowtimeStart().isBefore(deadline));
            if (tooLate) {
                throw ApiException.badRequest("Booking can only be cancelled at least "
                        + CANCEL_BEFORE_HOURS + " hours before the showtime");
            }
        }
        booking.setBookingStatus(BookingStatus.CANCELLED);
        jdbcTemplate.update("DELETE FROM seat_reservation WHERE booking_id = ?", bookingId);
        return BookingResponse.from(bookingRepository.save(booking));
    }

    // ======================= F9: REPORT =======================

    // TODO 9.2
    public ReportResponse report(LocalDate startDate, LocalDate endDate) {
        if (startDate.isAfter(endDate)) {                                    // BR13
            throw ApiException.badRequest("startDate must be before or equal to endDate");
        }
        List<Booking> bookings = bookingRepository.findForReport(BookingStatus.CONFIRMED,
                startDate.atStartOfDay(), endDate.plusDays(1).atStartOfDay());

        BigDecimal totalRevenue = BigDecimal.ZERO;
        long totalTickets = 0;
        Map<String, MovieRevenueResponse> byMovie = new HashMap<>();

        for (Booking b : bookings) {
            totalRevenue = totalRevenue.add(b.getTotalPrice());
            totalTickets += b.getDetails().size();
            for (BookingDetail d : b.getDetails()) {
                byMovie.merge(d.getMovieId(),
                        new MovieRevenueResponse(d.getMovieId(), d.getMovieTitle(), 1, d.getPrice()),
                        (a, c) -> new MovieRevenueResponse(a.movieId(), a.movieTitle(),
                                a.ticketsSold() + c.ticketsSold(), a.revenue().add(c.revenue())));
            }
        }

        // Sap xep GIAM DAN theo doanh thu, bang nhau thi theo so ve
        List<MovieRevenueResponse> revenueByMovie = byMovie.values().stream()
                .sorted(Comparator.comparing(MovieRevenueResponse::revenue).reversed()
                        .thenComparing(Comparator.comparingLong(MovieRevenueResponse::ticketsSold).reversed()))
                .toList();

        return new ReportResponse(startDate, endDate, bookings.size(), totalTickets, totalRevenue,
                revenueByMovie, bookings.stream().map(BookingResponse::from).toList()); // da desc tu query
    }

    // ======================= HELPER =======================

    private ShowtimeResponse fetchShowtime(String showtimeId) {
        try {
            return movieClient.getShowtime(showtimeId);
        } catch (FeignException.NotFound e) {
            throw ApiException.notFound("Showtime not found with id: " + showtimeId);
        } catch (FeignException e) {
            log.error("Cannot call movie-service: {}", e.getMessage());
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "Movie service is unavailable. Please try again later.");
        }
    }

    private void validateShowtime(ShowtimeResponse st) {
        if (!"SCHEDULED".equals(st.showtimeStatus())) {
            throw ApiException.badRequest("Showtime " + st.showtimeId() + " is not available (" + st.showtimeStatus() + ")");
        }
        if (!st.startTime().isAfter(LocalDateTime.now())) {
            throw ApiException.badRequest("Showtime " + st.showtimeId() + " has already started");
        }
    }

    /** Seat "E5": hang E (index 4) < seatRows va so 5 <= seatsPerRow */
    private void validateSeat(String seat, ShowtimeResponse st) {
        int rowIndex = seat.charAt(0) - 'A';
        int number = Integer.parseInt(seat.substring(1));
        if (rowIndex >= st.seatRows() || number > st.seatsPerRow()) {
            char lastRow = (char) ('A' + st.seatRows() - 1);
            throw ApiException.badRequest("Seat " + seat + " does not exist in room " + st.roomName()
                    + " (rows A-" + lastRow + ", seats 1-" + st.seatsPerRow() + ")");
        }
    }

    /** BR11: Customer chi truy cap booking cua minh, Admin truy cap tat ca */
    private Booking findAccessible(Long bookingId, Long userId, String role) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> ApiException.notFound("Booking not found with id: " + bookingId));
        if (!ROLE_ADMIN.equals(role) && !booking.getCustomerId().equals(userId)) {
            throw ApiException.forbidden("You can only access your own bookings");
        }
        return booking;
    }
}
