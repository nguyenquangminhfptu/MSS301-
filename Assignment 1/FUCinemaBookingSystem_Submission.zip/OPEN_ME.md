# Assignment 1 submission

The fu-cinema directory contains the four Java 21 services, Docker Compose,
database initialization and Flyway migrations, Postman collection and environment,
run scripts, captured verification evidence, and the completed Word report.

Open fu-cinema/docs/Assignment 1_Report.docx for the 21-page report covering all
54 TODO entries, results, screenshots of captured output, and commit references.
Student: Nguyen Quang Minh — DE190270 — SE19B04.

Read fu-cinema/README.md for setup, run commands, ports, and test accounts.
From fu-cinema, run scripts/build.sh, scripts/start.sh, and scripts/test-postman.sh.
Java 21, Maven, Docker, Node.js, and Newman are needed for the complete workflow.

Verification completed: 27 unit tests, 85 Postman requests with 159 assertions,
and 11 additional live regression checks passed. Evidence is in fu-cinema/evidence.
Captured output images use the Newman CLI and actual API/database results.

The included bundle preserves all 70 Conventional Commits on main and the
annotated submission tag v1.0.0. To inspect the history in a separate directory:

    git clone fu-cinema-history.bundle reviewed-fu-cinema
    git -C reviewed-fu-cinema log --oneline
    git -C reviewed-fu-cinema show v1.0.0

All 70 original assignment commits are now published, with their original hashes,
in https://github.com/nguyenquangminhfptu/MSS301-/commits/main. MSS301 main also includes integration commit f0887b2 and personalized report
commit e3758b549168f61aafd176bfac796cf4154d184d. The repository submission tag v1.0.0 marks
the integration commit. The bundle is the original 70-commit standalone snapshot
with its original submission tag; the report in this ZIP includes the student
details added after that snapshot.

Report formatting was corrected in commit 4288c29 (automatic Word TOC and
consistent font); screenshot instructions were added in commit e2ca9e4.
Read fu-cinema/docs/Huong-dan-chup-anh-va-hoan-thien-bao-cao.md.
The existing output figures are not Postman Desktop screenshots. Add actual
TODO completion and Desktop Runner/request screenshots, update the Word TOC,
and rebuild this archive before final submission under the instructor requirements.
